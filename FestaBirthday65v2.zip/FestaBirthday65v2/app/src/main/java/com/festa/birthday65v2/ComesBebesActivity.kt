package com.festa.birthday65v2

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class ComesBebesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comes_bebes)
        supportActionBar?.title = "Comes e Bebes"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val etNum = findViewById<EditText>(R.id.etNumConvidados)
        val btnCalc = findViewById<Button>(R.id.btnCalcular)
        val cardRes = findViewById<CardView>(R.id.cardResultado)

        val tvSalgados = findViewById<TextView>(R.id.tvSalgados)
        val tvDoces = findViewById<TextView>(R.id.tvDoces)
        val tvRefrigerante = findViewById<TextView>(R.id.tvRefrigerante)
        val tvSuco = findViewById<TextView>(R.id.tvSuco)
        val tvAgua = findViewById<TextView>(R.id.tvAgua)
        val tvBolo = findViewById<TextView>(R.id.tvBolo)
        val tvCerveja = findViewById<TextView>(R.id.tvCerveja)

        btnCalc.setOnClickListener {
            val numStr = etNum.text.toString().trim()
            if (numStr.isNotEmpty()) {
                val n = numStr.toIntOrNull()
                if (n != null && n > 0) {
                    // Cálculos baseados em médias para festa de adultos
                    val salgados = n * 12       // 12 salgados por pessoa
                    val doces = n * 6            // 6 doces por pessoa
                    val refri = (n * 0.35).toInt() // 350ml por pessoa → garrafas 2L
                    val suco = (n * 0.2).toInt()   // 200ml por pessoa → caixas 1L
                    val agua = (n * 0.5).toInt()   // 500ml por pessoa → garrafas 500ml
                    val bolo = Math.ceil(n / 15.0).toInt() // 1 bolo para 15 pessoas
                    val cerveja = (n * 0.5 * 3).toInt() // 50% bebem, 3 latas por pessoa

                    tvSalgados.text = "🥟 Salgados: $salgados unidades ($n × 12)"
                    tvDoces.text = "🍬 Doces/Brigadeiros: $doces unidades ($n × 6)"
                    tvRefrigerante.text = "🥤 Refrigerante: $refri garrafas 2L"
                    tvSuco.text = "🧃 Suco: $suco caixas 1L"
                    tvAgua.text = "💧 Água: $agua garrafas 500ml"
                    tvBolo.text = "🎂 Bolo: $bolo unidades (1 para cada 15 pessoas)"
                    tvCerveja.text = "🍺 Cerveja: $cerveja latas (estimativa 50% dos adultos)"

                    cardRes.visibility = View.VISIBLE
                    Toast.makeText(this, "✅ Cálculo para $n convidados!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Digite um número válido!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Digite a quantidade de convidados!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
