package com.festa.birthday65v2

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ConvidadosActivity : AppCompatActivity() {

    private val convidados = mutableListOf<String>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_convidados)
        supportActionBar?.title = "Lista de Convidados"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val etNome = findViewById<EditText>(R.id.etNomeConvidado)
        val btnAdicionar = findViewById<Button>(R.id.btnAdicionar)
        val lvConvidados = findViewById<ListView>(R.id.lvConvidados)
        val tvContador = findViewById<TextView>(R.id.tvContador)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, convidados)
        lvConvidados.adapter = adapter

        btnAdicionar.setOnClickListener {
            val nome = etNome.text.toString().trim()
            if (nome.isNotEmpty()) {
                convidados.add(nome)
                adapter.notifyDataSetChanged()
                etNome.text.clear()
                atualizarContador(tvContador)
                Toast.makeText(this, "✅ $nome adicionado!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Digite um nome!", Toast.LENGTH_SHORT).show()
            }
        }

        lvConvidados.setOnItemLongClickListener { _, _, pos, _ ->
            val nome = convidados[pos]
            convidados.removeAt(pos)
            adapter.notifyDataSetChanged()
            atualizarContador(tvContador)
            Toast.makeText(this, "❌ $nome removido", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun atualizarContador(tv: TextView) {
        val n = convidados.size
        tv.text = "$n ${if (n == 1) "convidado" else "convidados"}"
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
