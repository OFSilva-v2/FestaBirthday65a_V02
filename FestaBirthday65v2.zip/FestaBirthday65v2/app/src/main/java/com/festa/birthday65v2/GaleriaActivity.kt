package com.festa.birthday65v2

import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class GaleriaActivity : AppCompatActivity() {

    // Fotos reais do drawable
    data class FotoItem(val resId: Int, val titulo: String)

    private val fotos = listOf(
        FotoItem(R.drawable.foto1, "🎂 Emblema de Aniversário"),
        FotoItem(R.drawable.foto2, "🎉 Decoração da Festa"),
        FotoItem(R.drawable.foto3, "🥂 Celebração Especial")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_galeria)
        supportActionBar?.title = "Galeria de Fotos"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val gridView = findViewById<GridView>(R.id.gridView)
        gridView.adapter = GaleriaAdapter(this, fotos)

        gridView.setOnItemClickListener { _, _, pos, _ ->
            Toast.makeText(this, fotos[pos].titulo, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    inner class GaleriaAdapter(
        context: Context,
        private val items: List<FotoItem>
    ) : BaseAdapter() {

        private val ctx = context

        override fun getCount() = items.size
        override fun getItem(pos: Int) = items[pos]
        override fun getItemId(pos: Int) = pos.toLong()

        override fun getView(pos: Int, convertView: View?, parent: ViewGroup): View {
            val layout = LinearLayout(ctx)
            layout.orientation = LinearLayout.VERTICAL
            layout.gravity = android.view.Gravity.CENTER
            layout.setPadding(8, 8, 8, 8)

            val iv = ImageView(ctx)
            iv.setImageResource(items[pos].resId)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            val imgParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 280
            )
            imgParams.setMargins(0, 0, 0, 6)
            iv.layoutParams = imgParams

            val tv = TextView(ctx)
            tv.text = items[pos].titulo
            tv.textSize = 12f
            tv.gravity = android.view.Gravity.CENTER
            tv.setTextColor(0xFF212121.toInt())
            tv.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            layout.addView(iv)
            layout.addView(tv)
            layout.setBackgroundColor(0xFFFFFFFF.toInt())
            layout.layoutParams = AbsListView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 340
            )
            return layout
        }
    }
}
