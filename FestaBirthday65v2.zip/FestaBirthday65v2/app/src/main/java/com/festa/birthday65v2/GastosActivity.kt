package com.festa.birthday65v2

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

data class Gasto(val descricao: String, val valor: Double)

class GastosActivity : AppCompatActivity() {

    private val gastos = mutableListOf<Gasto>()
    private lateinit var adapter: ArrayAdapter<String>
    private var totalGeral = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gastos)
        supportActionBar?.title = "Controle de Gastos"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val etDesc = findViewById<EditText>(R.id.etDescricao)
        val etValor = findViewById<EditText>(R.id.etValor)
        val btnAdd = findViewById<Button>(R.id.btnAddGasto)
        val lvGastos = findViewById<ListView>(R.id.lvGastos)
        val tvTotal = findViewById<TextView>(R.id.tvTotalGeral)

        val displayList = mutableListOf<String>()
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, displayList)
        lvGastos.adapter = adapter

        btnAdd.setOnClickListener {
            val desc = etDesc.text.toString().trim()
            val valorStr = etValor.text.toString().trim()
            if (desc.isNotEmpty() && valorStr.isNotEmpty()) {
                val valor = valorStr.replace(",", ".").toDoubleOrNull()
                if (valor != null) {
                    gastos.add(Gasto(desc, valor))
                    displayList.add("💳 $desc — R$ %.2f".format(valor))
                    totalGeral += valor
                    tvTotal.text = "Total: R$ %.2f".format(totalGeral)
                    adapter.notifyDataSetChanged()
                    etDesc.text.clear()
                    etValor.text.clear()
                    Toast.makeText(this, "✅ Gasto adicionado!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Valor inválido!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
            }
        }

        lvGastos.setOnItemLongClickListener { _, _, pos, _ ->
            totalGeral -= gastos[pos].valor
            gastos.removeAt(pos)
            displayList.removeAt(pos)
            tvTotal.text = "Total: R$ %.2f".format(totalGeral)
            adapter.notifyDataSetChanged()
            Toast.makeText(this, "❌ Gasto removido (pressione longo)", Toast.LENGTH_SHORT).show()
            true
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
