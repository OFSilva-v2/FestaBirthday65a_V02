package com.festa.birthday65v2

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LocalizacaoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_localizacao)
        supportActionBar?.title = "Localização"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val webView = findViewById<WebView>(R.id.webViewMapa)
        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()

        // Embed Google Maps com endereço
        val mapHtml = """
            <html><body style="margin:0;padding:0;">
            <iframe
                width="100%" height="100%"
                frameborder="0" style="border:0"
                src="https://www.google.com/maps?q=Rua+das+Flores,+123,+Sao+Paulo&output=embed"
                allowfullscreen>
            </iframe>
            </body></html>
        """.trimIndent()
        webView.loadData(mapHtml, "text/html", "UTF-8")

        val btnMapa = findViewById<Button>(R.id.btnVerMapa)
        btnMapa.setOnClickListener {
            val uri = Uri.parse("geo:0,0?q=Rua+das+Flores,+123,+São+Paulo")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
            } else {
                // Fallback: abre no browser
                val browserIntent = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://maps.google.com/?q=Rua+das+Flores,+123,+São+Paulo"))
                startActivity(browserIntent)
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
