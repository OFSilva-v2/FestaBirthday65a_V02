package com.festa.birthday65v2

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.title = "Menu Principal"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        findViewById<LinearLayout>(R.id.cardConvidados).setOnClickListener {
            startActivity(Intent(this, ConvidadosActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.cardGastos).setOnClickListener {
            startActivity(Intent(this, GastosActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.cardComesBebes).setOnClickListener {
            startActivity(Intent(this, ComesBebesActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.cardGaleria).setOnClickListener {
            startActivity(Intent(this, GaleriaActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.cardLocalizacao).setOnClickListener {
            startActivity(Intent(this, LocalizacaoActivity::class.java))
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
